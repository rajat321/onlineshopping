 
<?php $__env->startSection('pageTitle'); ?> Admin <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <?php if(session()->has('message')): ?>
    <div class="alert alert-success" style="margin-left: 253px; margin-top: 11px;">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">             
                                <div class="card-body">
                                    <h4 class="card-title" style="text-align:center;">Menu Details</h4>
                        <?php echo Form::open(['url' => url('/admin/add-menu'),'enctype' => 'multipart/form-data']); ?>

                                     <?php echo e(csrf_field()); ?> 
                                    <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Menu Name</label>
<?php echo Form::text('name', null, array('required','class'=>'form-control col-sm-9','placeholder'=>'Menu Name')); ?>

                                    </div>

                         <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">URL</label>
<?php echo Form::text('url', null, array('required','class'=>'form-control col-sm-9','placeholder'=>'URL')); ?>

                                    </div>

                         <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Slug</label>
<?php echo Form::text('slug', null, array('required','class'=>'form-control col-sm-9','placeholder'=>'slug')); ?>

                                    </div>
<!-- 
                                      <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Add Category</label>
<select class="form-control col-md-9" name="submenu">
<option value="">Plese Select</option>
<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($res->name); ?>"><?php echo e($res->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
                                    </div> -->
                                <div class="border-top">
                                    <div class="card-body">
                                      <?php echo Form::submit('Submit', 
              array('class'=>'btn btn-primary','style'=>'margin-left: 50%;')); ?>

                                      <!--  <button type="submit" class="btn btn-primary" style="margin-left: 50%;">
                                    Submit
                                </button> -->
                                    </div>
                                </div>
                           <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
      <script type="text/javascript" src="<?php echo e(url('public/ckeditor/ckeditor.js')); ?>"></script>
            <script type="text/javascript">
         CKEDITOR.replace( 'messageArea',
         {
          customConfig : 'config.js',
          toolbar : 'simple'
          })
</script> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>