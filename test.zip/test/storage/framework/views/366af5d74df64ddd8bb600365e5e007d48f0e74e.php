 
<?php $__env->startSection('pageTitle'); ?> Admin <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <?php if(session()->has('message')): ?>
    <div class="alert alert-success" style="margin-left: 253px; margin-top: 11px;">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">             
                                <div class="card-body">
                                    <h4 class="card-title" style="text-align:center;">Menu Details</h4>
<?php echo Form::model($result,['url' => url('/admin/categoryupdate/'.$result->id),'enctype' => 'multipart/form-data']); ?>

<?php echo Form::hidden('id',old('id'), array('required')); ?>

  <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Category Name</label>
<?php echo Form::text('cat_name',old('cat_name'), array('required','class'=>'form-control col-sm-9','placeholder'=>'Category Name')); ?>

                                    </div>

<div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Parent Category</label>
<select name="parent_cat" class="form-control col-sm-9">
  <option value="self">Please Select</option>
  <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($value->cat_name); ?>"><?php echo e($value->cat_name); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
    <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Description</label>
<?php echo Form::textarea('cat_description',old('cat_description'), array('required','id'=>'cat_description')); ?>

    </div>

  <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Image</label>
<?php echo Form::file('cat_image',old('cat_image'), array('required','class'=>'form-control col-sm-9','placeholder'=>'image')); ?>

<img src="<?php echo e(url('public/uploads/product_image/'.$result->cat_image)); ?>" style="height:62px; width:90px;">
  </div>
 <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Status</label>
<label class="switch">
  <?php echo Form::checkbox('status',old('status'), array('required')); ?>

  <span class="slider round"></span>
</label>
                          </div>
                                <div class="border-top">
                                    <div class="card-body">
                                      <?php echo Form::submit('Submit', 
              array('class'=>'btn btn-primary','style'=>'margin-left: 50%;')); ?>

                                    </div>
                                </div>
                           <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
      <script type="text/javascript" src="<?php echo e(url('public/ckeditor/ckeditor.js')); ?>"></script>
            <script type="text/javascript">
         CKEDITOR.replace( 'cat_description',
         {
          customConfig : 'config.js',
          toolbar : 'simple'
          })
</script> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>