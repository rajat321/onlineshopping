 
<?php $__env->startSection('pageTitle'); ?> Admin <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <?php if(session()->has('message')): ?>
    <div class="alert alert-success" style="margin-left: 253px; margin-top: 11px;">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">             
                                <div class="card-body">
                                    <h4 class="card-title" style="text-align:center;">Personal Info</h4>
                        <?php echo Form::open(['url' => url('/admin/addslider'),'enctype' => 'multipart/form-data']); ?>

                                     <?php echo e(csrf_field()); ?> 
                                    <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Slider Title</label>
<?php echo Form::text('title', null, array('required','class'=>'form-control col-sm-9','placeholder'=>'Title')); ?>

                                    </div>

                                    <div class="form-group row">
                                        <label for="fname" class="col-sm-3 text-right control-label col-form-label">File Upload</label>
                                        <div class="col-sm-9">
                                             <input type="file" class="custom-file-input" name="image" id="validatedCustomFile" required>
                                            <label class="custom-file-label" for="validatedCustomFile">Choose file...</label>
                                             <div class="invalid-feedback">Example invalid custom file feedback</div>
                                        </div>
                                    </div>

                                      <div class="form-group row">
                                        <label for="fname" class="col-sm-3 text-right control-label col-form-label">Slider Title</label>
                                        <div class="col-sm-9">
  <?php echo Form::textarea('content', null, array('required','class'=>'form-control ckeditor', 
                      'placeholder'=>'Message',
                      'id'=>'messageArea')); ?>

                                        </div>
                                    </div>

                                <div class="border-top">
                                    <div class="card-body">
                                    	<?php echo Form::submit('Submit', 
              array('class'=>'btn btn-primary','style'=>'margin-left: 50%;')); ?>

                                      <!--  <button type="submit" class="btn btn-primary" style="margin-left: 50%;">
                                    Submit
                                </button> -->
                                    </div>
                                </div>
                           <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
      <script type="text/javascript" src="<?php echo e(url('public/ckeditor/ckeditor.js')); ?>"></script>
            <script type="text/javascript">
         CKEDITOR.replace( 'messageArea',
         {
          customConfig : 'config.js',
          toolbar : 'simple'
          })
</script> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>