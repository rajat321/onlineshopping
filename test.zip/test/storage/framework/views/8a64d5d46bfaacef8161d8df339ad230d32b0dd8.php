 
<?php $__env->startSection('pageTitle'); ?> Admin <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <?php if(session()->has('message')): ?>
    <div class="alert alert-success" style="margin-left: 253px; margin-top: 11px;">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">             
                                <div class="card-body">
                                    <h4 class="card-title" style="text-align:center;">Menu Details</h4>
<?php echo Form::model($result,['url' => url('/admin/productedit/'.$result->id),'enctype' => 'multipart/form-data']); ?>

<?php echo Form::hidden('id',old('id'), array('required')); ?>

  <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Product Name</label>
<?php echo Form::text('product_name',old('product_name'), array('required','class'=>'form-control col-sm-9','placeholder'=>'Product Name')); ?>

                                    </div>

                         <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Product Type</label>
<?php echo Form::text('product_type',old('product_type'), array('required','class'=>'form-control col-sm-9','placeholder'=>'Product Type')); ?>

                                    </div>

  <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Category</label>
<?php echo e(Form::select('category',$cat, old('category'), ["id"=>"category",'class' => 'form-control  col-sm-9'])); ?>

                                    </div>
                                  <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Product Type</label>
<?php echo e(Form::select('sub_category',$p_result, old('sub_category'), ["id"=>"sub_category",'class' => 'form-control  col-sm-9'])); ?>

                                    </div>    


                                            <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Description</label>
<?php echo Form::textarea('description',old('description'), array('required','id'=>'description')); ?>

                                    </div>

           <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Image</label>
<?php echo Form::file('image',old('image'), array('required','class'=>'form-control col-sm-9','placeholder'=>'image')); ?>

<img src="<?php echo e(url('public/uploads/product_image/'.$result->image)); ?>" style="height:62px; width:90px;">
              </div>

                         <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Price</label>
<?php echo Form::text('price',old('price'), array('required','class'=>'form-control col-sm-9','placeholder'=>'Price')); ?>

                          </div>

                            <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Stock</label>
<?php echo Form::text('stock',old('stock'), array('required','class'=>'form-control col-sm-9','placeholder'=>'Stock')); ?>

                          </div>
 <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Status</label>
<label class="switch">
  <?php echo Form::checkbox('status',old('status'), array('required')); ?>

  <span class="slider round"></span>
</label>
                          </div>
                                <div class="border-top">
                                    <div class="card-body">
                                      <?php echo Form::submit('Submit', 
              array('class'=>'btn btn-primary','style'=>'margin-left: 50%;')); ?>

                                    </div>
                                </div>
                           <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
      <script type="text/javascript" src="<?php echo e(url('public/ckeditor/ckeditor.js')); ?>"></script>
            <script type="text/javascript">
         CKEDITOR.replace( 'description',
         {
          customConfig : 'config.js',
          toolbar : 'simple'
          })
</script> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>