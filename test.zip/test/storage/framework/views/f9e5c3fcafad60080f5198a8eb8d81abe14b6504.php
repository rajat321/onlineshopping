 
<?php $__env->startSection('pageTitle'); ?> Admin <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
  .img_show{
    height: 100px;
    width: 150px;
}
  }
</style>
<link href="<?php echo e(url('public/admin/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/admin/assets/extra-libs/multicheck/multicheck.css')); ?>">
          <?php if(session()->has('message')): ?>
    <div class="alert alert-success" style="margin-left: 253px; margin-top: 11px;">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
<div class="page-wrapper">
          
           
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                      
                        <div class="card">
                            <div class="card-body">
                              <div class="row">
                              <div class="col-md-8">
                               <h5 class="card-title">Show Product List</h5> 
                              </div>
                              <div class="col-md-4">
                                <div class="pull-right" style="margin-left: 195px;
"><a href="<?php echo e(url('admin/addproduct')); ?>" class="btn btn-primary">Add Product</a></div>
                              </div>
                              </div>
                                
                                
                                <div class="table-responsive">
                                    <table id="zero_config" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>S.NO.</th>
                                                <th>Product Name</th>
                                                <th>Product Type</th>
                                                <th>Category</th>
                                                <th>Parent Category</th>
                                                <th>Description</th>
                                                <th>Image</th>
                                                <th>Price</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          <?php $count=1; ?>
                                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($count++); ?></td>
                                                <td><?php echo e($row->product_name); ?></td>
                                                <td><?php echo e($row->product_type); ?></td>
                                                <td><?php echo e($row->category); ?></td>
                                                <td><?php echo e($row->sub_category); ?></td>
                                                <td><?php echo $row->description; ?></td>
<td><img src="<?php echo e(url('public/uploads/product_image/'.$row->image)); ?>" style="height: 50px;width: 81px;"></td>
                                                <td><?php echo e($row->price); ?></td>
                                                <td><?php echo e($row->status); ?></td>
<td><a href="<?php echo e(url('admin/deleteproduct/'.$row->id)); ?>"><i class="fa fa-trash"></i></a>&nbsp;&nbsp;<a href="<?php echo e(url('admin/editproduct/'.$row->id)); ?>"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;<a href="<?php echo e(url('admin/showsubmenu/'.$row->id)); ?>"><i class="fas fa-cogs"></i></a></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                      
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
          
         
            <!-- ============================================================== -->
        </div>
 <script src="<?php echo e(url('public/admin/assets/extra-libs/DataTables/datatables.min.js')); ?>"></script>
  <script src="<?php echo e(url('public/admin/assets/extra-libs/multicheck/datatable-checkbox-init.js')); ?>"></script>
    <script src="<?php echo e(url('public/admin/assets/extra-libs/multicheck/jquery.multicheck.js')); ?>"></script>

    <script>
        /****************************************
         *       Basic Table                   *
         ****************************************/
        $('#zero_config').DataTable();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>