<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//use Function
use App\Slider;
//End Use Function
Route::get('/', function () {
	
	$slider=Slider::get();
    return view('welcome',compact('slider'));
});
Route::get('/home', 'HomeController@index')->name('home');

//Admin Route 
Route::group(['prefix' => 'admin'], function () {
//Slider Route Start
Route::get('/','AdminController@index')->name('admin.home');
Route::get('/slider','AdminController@slider')->name('admin.slider');
Route::post('/addslider','AdminController@addslider');
Route::get('/showslider','AdminController@show_slider');
Route::get('/sliderdelete/{id}','AdminController@sliderdelete');
Route::get('/editslider/{id}','AdminController@editslider');
Route::post('/updateslider/{id}','AdminController@updateslider');
Route::get('/setting','AdminController@setting');
//End Slider Route Start
//Menu Route Start
Route::get('/menu','AdminController@menu');
Route::get('/addmenu','AdminController@addmenu');
Route::post('/add-menu','AdminController@add_menu');
Route::get('/menudelete/{id}','AdminController@menudelete');
Route::get('/submenu/{id}','AdminController@submenu');
Route::post('/add-submenu/','AdminController@add_submenu');
Route::get('/showsubmenu/{id}','AdminController@showsubmenu');
//End Menu Route

//Product Route Start 
Route::get('/product','ProdutController@home');
Route::get('/addproduct','ProdutController@addproduct');
Route::post('/productadd','ProdutController@productadd');
Route::get('/editproduct/{id}','ProdutController@editproduct');
Route::post('/productedit/{id}','ProdutController@productedit');
Route::get('/deleteproduct/{id}','ProdutController@deleteproduct');
Route::post('/ajaxcategory','ProdutController@ajaxcategory');
//Product Route End 
//Category Route StART
Route::get('/category','ProdutController@category');
Route::get('/addcategory','ProdutController@addcategory');
Route::post('/categorystore','ProdutController@categorystore');
Route::get('/editcategory/{id}','ProdutController@editcategory');
Route::post('/categoryupdate/{id}','ProdutController@categoryupdate');
Route::get('/categorydelete/{id}','ProdutController@categorydelete');
Route::get('/subcategory/{id}','ProdutController@subcategory');
//Category Route End


});
//End Admin Route

