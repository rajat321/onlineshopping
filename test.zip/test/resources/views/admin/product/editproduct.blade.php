 @extends('layouts.admin')
@section('pageTitle') Admin @endsection
@section('content')
    <div class="container">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                @if(session()->has('message'))
    <div class="alert alert-success" style="margin-left: 253px; margin-top: 11px;">
        {{ session()->get('message') }}
    </div>
@endif
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">             
                                <div class="card-body">
                                    <h4 class="card-title" style="text-align:center;">Menu Details</h4>
{!! Form::model($result,['url' => url('/admin/productedit/'.$result->id),'enctype' => 'multipart/form-data']) !!}
{!! Form::hidden('id',old('id'), array('required')) !!}
  <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Product Name</label>
{!! Form::text('product_name',old('product_name'), array('required','class'=>'form-control col-sm-9','placeholder'=>'Product Name')) !!}
                                    </div>

                         <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Product Type</label>
{!! Form::text('product_type',old('product_type'), array('required','class'=>'form-control col-sm-9','placeholder'=>'Product Type')) !!}
                                    </div>

  <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Category</label>
{{ Form::select('category',$cat, old('category'), ["id"=>"category",'class' => 'form-control  col-sm-9']) }}
                                    </div>
                                  <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Product Type</label>
{{ Form::select('sub_category',$p_result, old('sub_category'), ["id"=>"sub_category",'class' => 'form-control  col-sm-9']) }}
                                    </div>    


                                            <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Description</label>
{!! Form::textarea('description',old('description'), array('required','id'=>'description')) !!}
                                    </div>

           <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Image</label>
{!! Form::file('image',old('image'), array('required','class'=>'form-control col-sm-9','placeholder'=>'image')) !!}
<img src="{{url('public/uploads/product_image/'.$result->image)}}" style="height:62px; width:90px;">
              </div>

                         <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Price</label>
{!! Form::text('price',old('price'), array('required','class'=>'form-control col-sm-9','placeholder'=>'Price')) !!}
                          </div>

                            <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Stock</label>
{!! Form::text('stock',old('stock'), array('required','class'=>'form-control col-sm-9','placeholder'=>'Stock')) !!}
                          </div>
 <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Status</label>
<label class="switch">
  {!! Form::checkbox('status',old('status'), array('required')) !!}
  <span class="slider round"></span>
</label>
                          </div>
                                <div class="border-top">
                                    <div class="card-body">
                                      {!! Form::submit('Submit', 
              array('class'=>'btn btn-primary','style'=>'margin-left: 50%;')) !!}
                                    </div>
                                </div>
                           {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
      <script type="text/javascript" src="{{url('public/ckeditor/ckeditor.js')}}"></script>
            <script type="text/javascript">
         CKEDITOR.replace( 'description',
         {
          customConfig : 'config.js',
          toolbar : 'simple'
          })
</script> 
@endsection
