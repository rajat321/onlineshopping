 @extends('layouts.admin')
@section('pageTitle') Admin @endsection
@section('content')
<style type="text/css">
  .img_show{
    height: 100px;
    width: 150px;
}
  }
</style>
<link href="{{url('public/admin/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')}}" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="{{url('public/admin/assets/extra-libs/multicheck/multicheck.css')}}">
          @if(session()->has('message'))
    <div class="alert alert-success" style="margin-left: 253px; margin-top: 11px;">
        {{ session()->get('message') }}
    </div>
@endif
<div class="page-wrapper">
          
           
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                      
                        <div class="card">
                            <div class="card-body">
                              <div class="row">
                              <div class="col-md-8">
                               <h5 class="card-title">Show Product List</h5> 
                              </div>
                              <div class="col-md-4">
                                <div class="pull-right" style="margin-left: 195px;
"><a href="{{url('admin/addproduct')}}" class="btn btn-primary">Add Product</a></div>
                              </div>
                              </div>
                                
                                
                                <div class="table-responsive">
                                    <table id="zero_config" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>S.NO.</th>
                                                <th>Product Name</th>
                                                <th>Product Type</th>
                                                <th>Category</th>
                                                <th>Parent Category</th>
                                                <th>Description</th>
                                                <th>Image</th>
                                                <th>Price</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          <?php $count=1; ?>
                                        @foreach($result as $row)
                                            <tr>
                                                <td>{{$count++}}</td>
                                                <td>{{$row->product_name}}</td>
                                                <td>{{$row->product_type}}</td>
                                                <td>{{$row->category}}</td>
                                                <td>{{$row->sub_category}}</td>
                                                <td>{!! $row->description !!}</td>
<td><img src="{{url('public/uploads/product_image/'.$row->image)}}" style="height: 50px;width: 81px;"></td>
                                                <td>{{$row->price}}</td>
                                                <td>{{$row->status}}</td>
<td><a href="{{url('admin/deleteproduct/'.$row->id)}}"><i class="fa fa-trash"></i></a>&nbsp;&nbsp;<a href="{{url('admin/editproduct/'.$row->id)}}"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;<a href="{{url('admin/showsubmenu/'.$row->id)}}"><i class="fas fa-cogs"></i></a></td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                      
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
          
         
            <!-- ============================================================== -->
        </div>
 <script src="{{url('public/admin/assets/extra-libs/DataTables/datatables.min.js')}}"></script>
  <script src="{{url('public/admin/assets/extra-libs/multicheck/datatable-checkbox-init.js')}}"></script>
    <script src="{{url('public/admin/assets/extra-libs/multicheck/jquery.multicheck.js')}}"></script>

    <script>
        /****************************************
         *       Basic Table                   *
         ****************************************/
        $('#zero_config').DataTable();
    </script>
@endsection
