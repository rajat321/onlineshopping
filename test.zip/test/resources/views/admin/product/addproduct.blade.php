 @extends('layouts.admin')
@section('pageTitle') Admin @endsection
@section('content')
    <div class="container">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                @if(session()->has('message'))
    <div class="alert alert-success" style="margin-left: 253px; margin-top: 11px;">
        {{ session()->get('message') }}
    </div>
@endif
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">             
                                <div class="card-body">
                                    <h4 class="card-title" style="text-align:center;">Product Details</h4>
{!! Form::model($result,['url' => url('/admin/productadd'),'enctype' => 'multipart/form-data']) !!}
  <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Product Name</label>
{!! Form::text('product_name', null, array('required','class'=>'form-control col-sm-9','placeholder'=>'Product Name')) !!}
                                    </div>

                         <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Product Type</label>
{!! Form::text('product_type', null, array('required','class'=>'form-control col-sm-9','placeholder'=>'Product Type')) !!}
                                    </div>
  <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Category</label>
{{ Form::select('category', $result, null,['class' => 'form-control col-sm-9','onchange' => "getsubcategory(this.value, '');"]) }}
  </div>
  <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Sub Category</label>
<!-- <select class="form-control" name="subcategory" id="subcategory">
<option value="">Select</option>
</select> -->
{{ Form::select('sub_category',$p_result, null, array('class' => 'form-control col-sm-9')) }}
  </div>

  <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Description</label>
<textarea name="description" id="description"></textarea>
                                    </div>

           <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Image</label>
{!! Form::file('image', null, array('required','class'=>'form-control col-sm-9','placeholder'=>'image')) !!}
                          </div>

                         <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Price</label>
{!! Form::text('price', null, array('required','class'=>'form-control col-sm-9','placeholder'=>'Price')) !!}
                          </div>

                            <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Stock</label>
{!! Form::text('stock', null, array('required','class'=>'form-control col-sm-9','placeholder'=>'Stock')) !!}
                          </div>
 <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Status</label>
<label class="switch">
  <input type="checkbox" name="status">
  <span class="slider round"></span>
</label>
                          </div>
                                <div class="border-top">
                                    <div class="card-body">
                                      {!! Form::submit('Submit', 
              array('class'=>'btn btn-primary','style'=>'margin-left: 50%;')) !!}
                                    </div>
                                </div>
                           {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
      <script type="text/javascript" src="{{url('public/ckeditor/ckeditor.js')}}"></script>
            <script type="text/javascript">
         CKEDITOR.replace( 'description',
         {
          customConfig : 'config.js',
          toolbar : 'simple'
          })
</script> 
<script type="text/javascript">
      function getsubcategory(val, subcategory) {

        $.ajax({

            type: "POST",
            url: "{{url('admin/ajaxcategory')}}",

            data: {"category": val, "subcategory": subcategory},

            success: function (data) {

                $("#subcategory").html(data);

            }

        });

    }
</script>
@endsection
