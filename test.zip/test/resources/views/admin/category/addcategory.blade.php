 @extends('layouts.admin')
@section('pageTitle') Admin @endsection
@section('content')
    <div class="container">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                @if(session()->has('message'))
    <div class="alert alert-success" style="margin-left: 253px; margin-top: 11px;">
        {{ session()->get('message') }}
    </div>
@endif
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">             
                                <div class="card-body">
                                    <h4 class="card-title" style="text-align:center;">Menu Details</h4>
{!! Form::open(['url' => url('/admin/categorystore'),'enctype' => 'multipart/form-data']) !!}
  <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Category Name</label>
{!! Form::text('cat_name', null, array('required','class'=>'form-control col-sm-9','placeholder'=>'Category Name')) !!}
                                    </div>

                         <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Parent Category</label>
<!-- {!! Form::text('product_type', null, array('required','class'=>'form-control col-sm-9','placeholder'=>'Product Type')) !!}
 -->
 <select name="parent_cat" class="form-control col-sm-9">
  <option value="Self">Please Select Parnet Category</option>
  @foreach($result as $value)
  <option value="{{$value->cat_name}}">{{$value->cat_name}}</option>
  @endforeach
 </select>                                 
</div>
  <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Description</label>

{!! Form::textarea('cat_description', null, array('required','class'=>'form-control col-sm-9','id'=>'cat_description','placeholder'=>'Category Name')) !!}

</div>

 <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Image</label>
{!! Form::file('cat_image', null, array('required','class'=>'form-control col-sm-9','placeholder'=>'cat_image')) !!}
   </div>

 <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Status</label>
<label class="switch">
  <input type="checkbox" name="status">
  <span class="slider round"></span>
</label>
                          </div>
                                <div class="border-top">
                                    <div class="card-body">
                                      {!! Form::submit('Submit', 
              array('class'=>'btn btn-primary','style'=>'margin-left: 50%;')) !!}
                                    </div>
                                </div>
                           {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
      <script type="text/javascript" src="{{url('public/ckeditor/ckeditor.js')}}"></script>
            <script type="text/javascript">
         CKEDITOR.replace( 'cat_description',
         {
          customConfig : 'config.js',
          toolbar : 'simple'
          })
</script> 
@endsection
