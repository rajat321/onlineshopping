 @extends('layouts.admin')
@section('pageTitle') Admin @endsection
@section('content')
    <div class="container">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                @if(session()->has('message'))
    <div class="alert alert-success" style="margin-left: 253px; margin-top: 11px;">
        {{ session()->get('message') }}
    </div>
@endif
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">             
                                <div class="card-body">
                                    <h4 class="card-title" style="text-align:center;">Menu Details</h4>
{!! Form::model($result,['url' => url('/admin/categoryupdate/'.$result->id),'enctype' => 'multipart/form-data']) !!}
{!! Form::hidden('id',old('id'), array('required')) !!}
  <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Category Name</label>
{!! Form::text('cat_name',old('cat_name'), array('required','class'=>'form-control col-sm-9','placeholder'=>'Category Name')) !!}
                                    </div>

<div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Parent Category</label>
<select name="parent_cat" class="form-control col-sm-9">
  <option value="self">Please Select</option>
  @foreach($category as $value)
  <option value="{{$value->cat_name}}">{{$value->cat_name}}</option>
  @endforeach
</select>
</div>
    <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Description</label>
{!! Form::textarea('cat_description',old('cat_description'), array('required','id'=>'cat_description')) !!}
    </div>

  <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Image</label>
{!! Form::file('cat_image',old('cat_image'), array('required','class'=>'form-control col-sm-9','placeholder'=>'image')) !!}
<img src="{{url('public/uploads/product_image/'.$result->cat_image)}}" style="height:62px; width:90px;">
  </div>
 <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Status</label>
<label class="switch">
  {!! Form::checkbox('status',old('status'), array('required')) !!}
  <span class="slider round"></span>
</label>
                          </div>
                                <div class="border-top">
                                    <div class="card-body">
                                      {!! Form::submit('Submit', 
              array('class'=>'btn btn-primary','style'=>'margin-left: 50%;')) !!}
                                    </div>
                                </div>
                           {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
      <script type="text/javascript" src="{{url('public/ckeditor/ckeditor.js')}}"></script>
            <script type="text/javascript">
         CKEDITOR.replace( 'cat_description',
         {
          customConfig : 'config.js',
          toolbar : 'simple'
          })
</script> 
@endsection
