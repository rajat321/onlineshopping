 @extends('layouts.admin')
@section('pageTitle') Admin @endsection
@section('content')
<style type="text/css">
  .img_show{
    height: 100px;
    width: 150px;
}
  }
</style>
<link href="{{url('public/admin/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')}}" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="{{url('public/admin/assets/extra-libs/multicheck/multicheck.css')}}">
          @if(session()->has('message'))
    <div class="alert alert-success" style="margin-left: 253px; margin-top: 11px;">
        {{ session()->get('message') }}
    </div>
@endif
<div class="page-wrapper">
          
           
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                      
                        <div class="card">
                            <div class="card-body">
                              <div class="row">
                              <div class="col-md-8">
                               <h5 class="card-title" style="text-align:center;">Show Menu List</h5> 
                              </div>
                              <div class="col-md-4">
                                <div class=""><a href="{{url('admin/addmenu')}}" class="btn btn-primary">Add Menu</a></div>
                              </div>
                              </div>
                                
                                
                                <div class="table-responsive">
                                    <table id="zero_config" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>S.NO.</th>
                                                <th>Name</th>
                                                <th>URL</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          <?php $count=1; ?>
                                        @foreach($result as $row)
                                            <tr>
                                                <td>{{$count++}}</td>
                                                <td>{{$row->name}}</td>
                                                <td>{{$row->url}}</td>
<td><a href="{{url('admin/editslider/')}}"><i class="far fa-eye-slash"></i></a>&nbsp;&nbsp;<a href="{{url('admin/menudelete/'.$row->id)}}"><i class="fa fa-trash"></i></a>&nbsp;&nbsp;<a href="{{url('admin/submenu/'.$row->id)}}"><i class="fa fa-edit"></i></a></td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                      
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
          
         
            <!-- ============================================================== -->
        </div>
 <script src="{{url('public/admin/assets/extra-libs/DataTables/datatables.min.js')}}"></script>
  <script src="{{url('public/admin/assets/extra-libs/multicheck/datatable-checkbox-init.js')}}"></script>
    <script src="{{url('public/admin/assets/extra-libs/multicheck/jquery.multicheck.js')}}"></script>

    <script>
        /****************************************
         *       Basic Table                   *
         ****************************************/
        $('#zero_config').DataTable();
    </script>
@endsection
