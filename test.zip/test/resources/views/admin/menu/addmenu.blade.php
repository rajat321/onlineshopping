 @extends('layouts.admin')
@section('pageTitle') Admin @endsection
@section('content')
    <div class="container">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                @if(session()->has('message'))
    <div class="alert alert-success" style="margin-left: 253px; margin-top: 11px;">
        {{ session()->get('message') }}
    </div>
@endif
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">             
                                <div class="card-body">
                                    <h4 class="card-title" style="text-align:center;">Menu Details</h4>
                        {!! Form::open(['url' => url('/admin/add-menu'),'enctype' => 'multipart/form-data']) !!}
                                     {{ csrf_field() }} 
                                    <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Menu Name</label>
{!! Form::text('name', null, array('required','class'=>'form-control col-sm-9','placeholder'=>'Menu Name')) !!}
                                    </div>

                         <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">URL</label>
{!! Form::text('url', null, array('required','class'=>'form-control col-sm-9','placeholder'=>'URL')) !!}
                                    </div>

                         <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Slug</label>
{!! Form::text('slug', null, array('required','class'=>'form-control col-sm-9','placeholder'=>'slug')) !!}
                                    </div>
<!-- 
                                      <div class="form-group row"> 
<label for="fname" class="col-sm-3 text-right control-label col-form-label">Add Category</label>
<select class="form-control col-md-9" name="submenu">
<option value="">Plese Select</option>
@foreach($result as $res)
<option value="{{$res->name}}">{{$res->name}}</option>
@endforeach
</select>
                                    </div> -->
                                <div class="border-top">
                                    <div class="card-body">
                                      {!! Form::submit('Submit', 
              array('class'=>'btn btn-primary','style'=>'margin-left: 50%;')) !!}
                                      <!--  <button type="submit" class="btn btn-primary" style="margin-left: 50%;">
                                    Submit
                                </button> -->
                                    </div>
                                </div>
                           {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
      <script type="text/javascript" src="{{url('public/ckeditor/ckeditor.js')}}"></script>
            <script type="text/javascript">
         CKEDITOR.replace( 'messageArea',
         {
          customConfig : 'config.js',
          toolbar : 'simple'
          })
</script> 
@endsection
