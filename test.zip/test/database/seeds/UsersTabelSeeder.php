<?php

use Illuminate\Database\Seeder;
use APP\User;

class UsersTabelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
           'name' => 'Rajat Sharma',
           'email' => 'rajat@gmail.com';
           'password' => Hash::Make('password'),
           'remember_token' => str_random(10),
]);
    }
}
