<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Produt extends Model
{
 
     protected $table="products";
     protected $fillable = ['product_name','product_type','description','image','price','stock','status','category','sub_category'];


     public function category(){
    	return $this->hasOne('App\Category', 'id', 'category');
    }

}
