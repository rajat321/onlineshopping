<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
Use App\Produt;
use App\Category;
use DB;
class ProdutController extends Controller
{
    

  public function home(){
    $result=Produt::get();
  	return view('admin.product.home',compact('result'));
  }

  public function addproduct(){
    $result = Category::pluck('cat_name','cat_name');
    $p_result = Category::pluck('parent_cat','parent_cat');

  	return view('admin.product.addproduct',compact('result','p_result'));
  }

  public function productadd(Request $request){
  $input=$request->all();
  if($request->file('image')){
    $input['image'] =$this->fileUpload($request->file('image'),time().'_'.rand(1000, 9999));
    }
    Produt::create($input);
   // DB::table('slider')->insert($input);
   return redirect('admin/product')->with('message', 'Message send successfully.');

  }

public function editproduct($id){
$result=Produt::findorfail($id);
$cat = Category::pluck('cat_name','cat_name');
$p_result = Category::pluck('parent_cat','parent_cat');
return view('admin.product.editproduct',compact('result','cat','p_result'));
}

public function productedit(Request $request,$id){
$input=$request->all();
$task=Produt::findorfail($id);
          if($request->file('image')){
$input['image'] =$this->fileUpload($request->file('image'),time().'_'.rand(1000, 9999));
}        
$task->fill($input)->save();
return redirect('admin/product')->with('message','successfully Update !!');
}

public function deleteproduct($id){
  DB::delete('delete from products where id = ?',[$id]);
  return redirect('admin/product')->with('message','Delete successfully!!');
}
//Add CAtegory Data 
public function category(){
  $result=Category::get();

  return view('admin.category.home',compact('result'));
}

public function addcategory(){
  $result=Category::get();
  return view('admin.category.addcategory',compact('result'));
}

public function categorystore(Request $request){
$input=$request->all();
      if($request->file('cat_image')){
$input['cat_image'] =$this->fileUpload($request->file('cat_image'),time().'_'.rand(1000, 9999));
}   
$result=Category::create($input);
if($result){
  return redirect('admin/category/')->with('message','successfully Submitted Category !!');
}else{
    echo "<script>alert('please check data');</script>";
    }
}

public function editcategory($id){
  $result=Category::findorfail($id);
  $category=Category::get();
  return view('admin/category/editcategory',compact('result','category'));
}

public function categoryupdate(Request $request,$id){
$input=$request->all();
$task=Category::findorfail($id);
          if($request->file('cat_image')){
$input['cat_image'] =$this->fileUpload($request->file('cat_image'),time().'_'.rand(1000, 9999));
}        
$task->fill($input)->save();
return redirect('admin/category')->with('message','successfully Update !!');

}

public function categorydelete($id){
  DB::delete('delete from p_category where id = ?',[$id]);
  return redirect('admin/category/')->with('message','Delete successfully!!');
}


public function ajaxcategory(Request $request){
  $input=$request->all();
  print_r($input);exit;
}

  function subcategory(Request $request) {
    $input=$request->get('category');
    print_r($input);exit;
        $sector = DB::table('category')->where('id',$request->get('category'))->pluck('name','name');
        $html="";
        $others=0;
        foreach ($sector as $key => $value) {
            $html.='<option value="'.$key.'">'.$value.'</option>';
            if($value=='Others'){
                $others=1;
            }
        }
        if($others==0 && !empty($request->get('category'))){
            $html.='<option value="Others">Others</option>';
        }
        return $html;
    }

//End Categry Data 

public function fileUpload($image,$fname)
{
    $input['imagename'] = $fname.'.'.$image->getClientOriginalExtension();
    $destinationPath = public_path('uploads/product_image');
    $image->move($destinationPath, $input['imagename']);
    return $input['imagename'];
}


}
