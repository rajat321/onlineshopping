<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use Box\Spout\Writer\WriterFactory;
use DB;
use App\Slider;
use App\Menu;
use App\Submenu;
class AdminController extends Controller
{
    public function index(){
    	return view('admin.home');
    }
//Slider Part of admin
/*-----------------------------------------------------------------------------------------*/

    public function show_slider()
    {
     $slider=Slider::get();   
        return view('admin.show_slider',compact('slider'));
    }

    public function slider()
    {
       
        return view('admin.slider');
    }
 
     public function editslider($id)
    {
       $result=Slider::findorfail($id);
        return view('admin.editslider',compact('result'));
    }

    public function updateslider(Request $request,$id){
        $input=$request->all();
        $task=Slider::findorfail($id);
          if($request->file('image')){
        $input['image'] =$this->fileUpload($request->file('image'),time().'_'.rand(1000, 9999));
    }
        
$task->fill($input)->save();
        return redirect('/admin/showslider')->with('message','successfully Update !!');

    }


    public function addslider(Request $request){
    $input=$request->all();
    if($request->file('image')){
    $input['image'] =$this->fileUpload($request->file('image'),time().'_'.rand(1000, 9999));
    }
    Slider::create($input);
   // DB::table('slider')->insert($input);
   return redirect('/admin/showslider')->with('message', 'Message send successfully.');
    }

   public function sliderdelete($id){
    
     $delete = Slider::find($id);
     $delete->delete();
     return redirect()->back()->with('message', 'Delete Data successfully.');
   //  return Redirect::route('admin/admins');

   }

//End Of Slider Part of admin
/*-----------------------------------------------------------------------------------------*/

//Start Part Of MEnu Section 
/*-----------------------------------------------------------------------------------------*/

public function menu(){
    $result=Menu::get();
    return view('admin.menu.home',compact('result'));
}

public function addmenu(){
  // print_r('hello');exit;
    $result=Menu::get();
    return view('admin.menu.addmenu',compact('result'));
}

public function add_menu(Request $request){
    $input=$request->all();
    Menu::create($input);
    return redirect('/admin/menu')->with('message', 'Message send successfully.');
}

public function menudelete($id){
    $delete = Menu::Find($id);
    $subdelete=Submenu::where('menu_id',$id)->firstorfail();
    if(!empty($subdelete)){
      $subdelete->delete();
    }
    $delete->delete();
    return redirect()->back()->with('message', 'Delete Data successfully.');
}

public function submenu($id){
    $menu_id=$id;
    return view('admin.menu.submenu',compact('menu_id'));
}

public function add_submenu(Request $request){
$input=$request->all();
Submenu::create($input);
return redirect('admin/menu')->with('message','Data Insert successfully');
}

public function showsubmenu($id){
    $result=Submenu::where('menu_id',$id)->get();
    //print_r($result);exit;
    return view('admin.menu.showsubmenu',compact('result'));
}

//End Part Of Menu Section
/*-----------------------------------------------------------------------------------------*/

//Home Page Setting 

public function setting(){
  return view('admin.homesetting');
}


//Home Page Setting End 
/*-----------------------------------------------------------------------------------------*/


   public function fileUpload($image,$fname)
{
//$image = $request->file('image');
    $input['imagename'] = $fname.'.'.$image->getClientOriginalExtension();
    $destinationPath = public_path('images/slider');
    $image->move($destinationPath, $input['imagename']);
//$this->postImage->add($input);
    return $input['imagename'];
}
   
}
