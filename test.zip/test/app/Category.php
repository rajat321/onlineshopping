<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    
    Protected $table="category";
    Protected $fillable=['cat_name','parent_cat','cat_description','cat_image','status'];
}
